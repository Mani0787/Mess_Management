<?php
include("header.php");
?>



<!DOCTYPEhtml>
<html lang="en">
<head>
 <title>About Us</title>
  <meta charset="utf-8">
 <meta name="viewport" content="width= device-width, initial-scale=1">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
 
 <style>
 
 .header
 {
     color:black;
 }
 }

.txt
{
   
    
   
}



.link
{
	
font-size:30px;	
	
}

body
    {
        background:none!important;
    }
    
  .container
  {
      
      padding:150px 3px;
  }
 </style>
 
 
 
 
 </head>
<body>



<div class="container">
    <div class="row sticky-top">
       <div class="col-md-12">
           <h1 style="text-align:center">About Us</h1>
           <br>
       </div>
  </div>
         <img src="canteen.jpg" alt="canteen" class="hight" height="500px" width="100%"> 
<br><br>
<h2 class="text">Mess Staff</h2><br>
<div class="row crl">
		<div class="col-md-3">
			<div class="card">
				<img class="card-img-top" src="chef.jpg">
				<div class="card-body">
					<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<img src="chef2.jpg" class="card-img-top">
				<div class="card-body">
					<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<img src="chef.jpg" class="card-img-top">
				<div class="card-body">
					<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<img src="chef2.jpg" class="card-img-top">
				<div class="card-body">
					<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
			</div>
		</div>
	</div><br>

<br>
 <h2> Mess Committee</h2>
<div class="row">
		<div class="col-md-3">
			<div class="card">
				<div class="card-body">
					<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
				<img src="commite.png" class="card-img-bottom">
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<div class="card-body">
				<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
					<img src="commite.png" class="card-img-bottom">
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<div class="card-body">
					<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
				<img src="commite.png" class="card-img-bottom">
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<div class="card-body">
					<h6 class="card-title">Name :</h6>
					<h6 class="card-title">Contact Number:9876543211</h6>
				</div>
				<img src="commite.png" class="card-img-bottom">
			</div>
		</div>
	</div>
</div>



</body>
</html>