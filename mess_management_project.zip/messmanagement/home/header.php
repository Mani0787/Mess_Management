<!DOCTYPE html>
<html>
    <head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    
    
    <style>
    body{
        background:none!important;
    }
    .nav-link{
       margin:0 10px 0 10px;
       color:black;
       font-size:20px;
    }
    </style>
    </head>
    <body>
        <div class="container-fluid">
        <header class="header">
        <nav class="navbar navbar-expand-sm fixed-top justify-content-between bg-light ">
            <a class="navbar-brand" href="#"> <img src="webs-removebg-preview.png" width="300" class="iiitr"></a>


 

 <ul class="navbar-nav ">
    <li class="nav-item">
      <a class="nav-link" href="index.php">Home</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="menu.php">Menu</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="aboutus.php">About</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="adminlogin.php">Admin</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="student_login.php">Student Login</a>
    </li>
  </ul>




         
        </nav>
    </header>
        </div>
    </body>
</html>